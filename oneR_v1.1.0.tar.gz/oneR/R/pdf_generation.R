#' Generate PDF Report using Alternative Methods
#'
#' This function creates PDF reports using alternative methods that don't rely
#' on rmarkdown/knitr. It uses markdown generation followed by PDF conversion.
#'
#' @param oneR_result An object of class "oneR" from oneR_test()
#' @param output_file Path for the output PDF file (default: "oneR_report.pdf")
#' @param title Title for the report (default: "Statistical Analysis Report")
#' @param author Author name for the report (default: "oneR Package")
#' @param include_data Logical, whether to include raw data in the report (default: FALSE)
#' @param include_plots Logical, whether to include plots in the report (default: TRUE)
#'
#' @return Path to the generated PDF file
#' @export
oneR_report_pdf <- function(oneR_result, output_file = "oneR_report.pdf", 
                           title = "Statistical Analysis Report", 
                           author = "oneR Package", include_data = FALSE,
                           include_plots = TRUE) {
  
  if (!inherits(oneR_result, "oneR")) {
    stop("Input must be an object of class 'oneR'")
  }
  
  # Create temporary markdown file
  temp_md <- tempfile(fileext = ".md")
  
  tryCatch({
    # Generate markdown content
    md_content <- generate_markdown_report_enhanced(oneR_result, title, author, include_data, include_plots)
    
    # Write markdown file
    writeLines(md_content, temp_md, useBytes = TRUE)
    
    # Try different PDF generation methods
    pdf_generated <- FALSE
    
    # Method 1: Use manus-md-to-pdf utility if available
    if (Sys.which("manus-md-to-pdf") != "") {
      cat("Attempting PDF generation using manus-md-to-pdf...\n")
      result <- system2("manus-md-to-pdf", args = c(temp_md, output_file), 
                       stdout = TRUE, stderr = TRUE)
      if (file.exists(output_file)) {
        pdf_generated <- TRUE
        cat("PDF generated successfully using manus-md-to-pdf:", output_file, "\n")
      }
    }
    
    # Method 2: Use pandoc if available
    if (!pdf_generated && Sys.which("pandoc") != "") {
      cat("Attempting PDF generation using pandoc...\n")
      result <- system2("pandoc", 
                       args = c(temp_md, "-o", output_file, "--pdf-engine=pdflatex"),
                       stdout = TRUE, stderr = TRUE)
      if (file.exists(output_file)) {
        pdf_generated <- TRUE
        cat("PDF generated successfully using pandoc:", output_file, "\n")
      }
    }
    
    # Method 3: Generate HTML and suggest conversion
    if (!pdf_generated) {
      cat("PDF generation tools not available. Creating HTML report instead...\n")
      html_file <- sub("\\.pdf$", ".html", output_file)
      
      # Generate HTML report
      html_content <- generate_html_report_enhanced(oneR_result, title, author, include_data, include_plots)
      writeLines(html_content, html_file, useBytes = TRUE)
      
      cat("HTML report generated:", html_file, "\n")
      cat("To convert to PDF:\n")
      cat("1. Open", html_file, "in a web browser\n")
      cat("2. Use 'Print to PDF' option\n")
      cat("3. Or install pandoc/LaTeX for automatic PDF generation\n")
      
      return(html_file)
    }
    
    # Clean up temporary file
    unlink(temp_md)
    
    return(output_file)
    
  }, error = function(e) {
    # Fallback: create HTML report
    warning("PDF generation failed: ", e$message, ". Creating HTML report instead.")
    html_file <- sub("\\.pdf$", ".html", output_file)
    
    html_content <- generate_html_report_enhanced(oneR_result, title, author, include_data, include_plots)
    writeLines(html_content, html_file, useBytes = TRUE)
    
    cat("HTML report generated:", html_file, "\n")
    return(html_file)
  })
}

#' Generate enhanced markdown report with plots
#'
#' @param oneR_result oneR test results
#' @param title Report title
#' @param author Report author
#' @param include_data Whether to include raw data
#' @param include_plots Whether to include plots
#'
#' @return Character vector with enhanced markdown content
#' @keywords internal
generate_markdown_report_enhanced <- function(oneR_result, title, author, include_data, include_plots) {
  
  x <- oneR_result$data_x
  y <- oneR_result$data_y
  is_two_sample <- !is.null(y)
  
  # Generate plots if requested
  plot_files <- c()
  if (include_plots) {
    plot_files <- generate_report_plots(oneR_result)
  }
  
  md_content <- c(
    paste("#", title),
    "",
    paste("**Author:** ", author),
    paste("**Generated:** ", Sys.time()),
    paste("**oneR Package Version:** 1.0.0"),
    "",
    "---",
    "",
    "## Executive Summary",
    "",
    generate_executive_summary_md(oneR_result),
    "",
    "## Data Overview",
    "",
    generate_data_overview_md(x, y),
    "",
    "## Normality Assessment",
    "",
    generate_normality_assessment_md(oneR_result),
    "",
    "## Statistical Test Results",
    "",
    generate_test_results_md(oneR_result),
    ""
  )
  
  # Add plots if available
  if (include_plots && length(plot_files) > 0) {
    md_content <- c(md_content,
      "## Visualizations",
      "",
      "### Normality Assessment Plots",
      "",
      paste("![Normality Assessment](", plot_files[1], ")"),
      "",
      "### Test Results Plots", 
      "",
      paste("![Test Results](", plot_files[2], ")"),
      ""
    )
  }
  
  md_content <- c(md_content,
    "## Interpretation and Recommendations",
    "",
    generate_interpretation_md(oneR_result),
    "",
    "## Technical Details",
    "",
    generate_technical_details_md(oneR_result)
  )
  
  # Add raw data if requested
  if (include_data) {
    md_content <- c(md_content,
      "",
      "## Raw Data",
      "",
      generate_raw_data_md(x, y)
    )
  }
  
  return(md_content)
}

#' Generate enhanced HTML report with plots
#'
#' @param oneR_result oneR test results
#' @param title Report title
#' @param author Report author
#' @param include_data Whether to include raw data
#' @param include_plots Whether to include plots
#'
#' @return Character vector with enhanced HTML content
#' @keywords internal
generate_html_report_enhanced <- function(oneR_result, title, author, include_data, include_plots) {
  
  x <- oneR_result$data_x
  y <- oneR_result$data_y
  
  # Generate plots if requested
  plot_files <- c()
  if (include_plots) {
    plot_files <- generate_report_plots(oneR_result)
  }
  
  html_content <- c(
    "<!DOCTYPE html>",
    "<html lang='en'>",
    "<head>",
    "    <meta charset='UTF-8'>",
    "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
    paste0("    <title>", title, "</title>"),
    generate_enhanced_css(),
    "</head>",
    "<body>",
    "    <div class='container'>",
    paste0("        <h1>", title, "</h1>"),
    "        <div class='metadata'>",
    paste0("            <p><strong>Author:</strong> ", author, "</p>"),
    paste0("            <p><strong>Generated:</strong> ", Sys.time(), "</p>"),
    "            <p><strong>oneR Package Version:</strong> 1.0.0</p>",
    "        </div>",
    "",
    "        <div class='executive-summary'>",
    "            <h2>Executive Summary</h2>",
    generate_executive_summary_html(oneR_result),
    "        </div>",
    "",
    "        <h2>Data Overview</h2>",
    generate_data_overview_html(x, y),
    "",
    "        <h2>Normality Assessment</h2>",
    generate_normality_assessment_html(oneR_result),
    "",
    "        <h2>Statistical Test Results</h2>",
    generate_test_results_html(oneR_result),
    ""
  )
  
  # Add plots if available
  if (include_plots && length(plot_files) > 0) {
    html_content <- c(html_content,
      "        <h2>Visualizations</h2>",
      "        <div class='plots-section'>",
      "            <h3>Normality Assessment</h3>",
      paste0("            <img src='", plot_files[1], "' alt='Normality Assessment Plots' class='plot-image'>"),
      "            <h3>Test Results</h3>",
      paste0("            <img src='", plot_files[2], "' alt='Test Results Plots' class='plot-image'>"),
      "        </div>",
      ""
    )
  }
  
  html_content <- c(html_content,
    "        <h2>Interpretation and Recommendations</h2>",
    "        <div class='recommendation'>",
    generate_interpretation_html(oneR_result),
    "        </div>",
    "",
    "        <h2>Technical Details</h2>",
    generate_technical_details_html(oneR_result)
  )
  
  # Add raw data if requested
  if (include_data) {
    html_content <- c(html_content,
      "",
      "        <h2>Raw Data</h2>",
      generate_raw_data_html(x, y)
    )
  }
  
  html_content <- c(html_content,
    "    </div>",
    "</body>",
    "</html>"
  )
  
  return(html_content)
}

#' Generate plots for report
#'
#' @param oneR_result oneR test results
#'
#' @return Vector of plot filenames
#' @keywords internal
generate_report_plots <- function(oneR_result) {
  
  # Generate normality plots
  normality_file <- "report_normality_plots.png"
  tryCatch({
    plot_normality(oneR_result, save_plot = TRUE, filename = normality_file)
  }, error = function(e) {
    cat("Warning: Could not generate normality plots:", e$message, "\n")
    normality_file <<- NULL
  })
  
  # Generate results plots
  results_file <- "report_results_plots.png"
  tryCatch({
    plot_results(oneR_result, save_plot = TRUE, filename = results_file)
  }, error = function(e) {
    cat("Warning: Could not generate results plots:", e$message, "\n")
    results_file <<- NULL
  })
  
  return(c(normality_file, results_file)[!is.null(c(normality_file, results_file))])
}

#' Generate enhanced CSS for HTML reports
#'
#' @return Character vector with CSS styles
#' @keywords internal
generate_enhanced_css <- function() {
  c(
    "    <style>",
    "        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f8f9fa; }",
    "        .container { max-width: 1000px; margin: 0 auto; padding: 20px; background-color: white; box-shadow: 0 0 10px rgba(0,0,0,0.1); }",
    "        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; margin-bottom: 30px; }",
    "        h2 { color: #34495e; border-bottom: 2px solid #bdc3c7; padding-bottom: 10px; margin-top: 40px; }",
    "        h3 { color: #7f8c8d; margin-top: 30px; }",
    "        .metadata { background-color: #ecf0f1; padding: 15px; border-radius: 8px; margin-bottom: 30px; }",
    "        .executive-summary { background-color: #e8f6f3; padding: 20px; border-radius: 8px; border-left: 5px solid #27ae60; margin-bottom: 30px; }",
    "        .result-table { border-collapse: collapse; width: 100%; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }",
    "        .result-table th, .result-table td { border: 1px solid #ddd; padding: 12px; text-align: left; }",
    "        .result-table th { background-color: #3498db; color: white; font-weight: bold; }",
    "        .result-table tr:nth-child(even) { background-color: #f2f2f2; }",
    "        .significant { color: #e74c3c; font-weight: bold; }",
    "        .not-significant { color: #27ae60; font-weight: bold; }",
    "        .normal { color: #27ae60; font-weight: bold; }",
    "        .non-normal { color: #e74c3c; font-weight: bold; }",
    "        .recommendation { background-color: #d5f4e6; padding: 20px; border-radius: 8px; border-left: 5px solid #27ae60; margin: 20px 0; }",
    "        .plots-section { margin: 30px 0; }",
    "        .plot-image { max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 8px; margin: 15px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }",
    "        .code-block { background-color: #f8f9fa; padding: 15px; border-radius: 5px; font-family: 'Courier New', monospace; border-left: 4px solid #6c757d; margin: 15px 0; }",
    "        .highlight-box { background-color: #fff3cd; padding: 15px; border-radius: 5px; border-left: 4px solid #ffc107; margin: 15px 0; }",
    "        @media print { body { background-color: white; } .container { box-shadow: none; } }",
    "    </style>"
  )
}

# Helper functions for enhanced content generation
generate_executive_summary_md <- function(oneR_result) {
  c(
    paste("- **Test Performed:** ", oneR_result$test_used),
    paste("- **P-value:** ", round(oneR_result$test_result$p.value, 4)),
    paste("- **Statistically Significant:** ", ifelse(oneR_result$test_result$p.value < oneR_result$parameters$alpha, "**Yes**", "**No**")),
    paste("- **Normality Assumption Met:** ", ifelse(oneR_result$is_normal, "**Yes**", "**No**")),
    "",
    "**Key Finding:** ", 
    ifelse(oneR_result$test_result$p.value < oneR_result$parameters$alpha,
           "The analysis detected a statistically significant difference.",
           "The analysis did not detect a statistically significant difference.")
  )
}

generate_executive_summary_html <- function(oneR_result) {
  c(
    "            <div class='highlight-box'>",
    paste0("                <p><strong>Test Performed:</strong> ", oneR_result$test_used, "</p>"),
    paste0("                <p><strong>P-value:</strong> ", round(oneR_result$test_result$p.value, 4), "</p>"),
    paste0("                <p><strong>Statistically Significant:</strong> <span class='", 
           ifelse(oneR_result$test_result$p.value < oneR_result$parameters$alpha, "significant'>Yes", "not-significant'>No"), 
           "</span></p>"),
    paste0("                <p><strong>Normality Assumption Met:</strong> <span class='", 
           ifelse(oneR_result$is_normal, "normal'>Yes", "non-normal'>No"), 
           "</span></p>"),
    "            </div>",
    paste0("            <p><strong>Key Finding:</strong> ", 
           ifelse(oneR_result$test_result$p.value < oneR_result$parameters$alpha,
                  "The analysis detected a statistically significant difference.",
                  "The analysis did not detect a statistically significant difference."), "</p>")
  )
}

generate_data_overview_md <- function(x, y) {
  content <- c(
    "| Statistic | Group X |"
  )
  
  if (!is.null(y)) {
    content[1] <- paste(content[1], "Group Y |")
    content <- c(content, "|-----------|---------|---------|")
  } else {
    content <- c(content, "|-----------|---------|")
  }
  
  if (!is.null(y)) {
    stats <- c(
      paste("| Sample Size |", length(x), "|", length(y), "|"),
      paste("| Mean |", round(mean(x), 4), "|", round(mean(y), 4), "|"),
      paste("| Standard Deviation |", round(sd(x), 4), "|", round(sd(y), 4), "|"),
      paste("| Median |", round(median(x), 4), "|", round(median(y), 4), "|"),
      paste("| Min |", round(min(x), 4), "|", round(min(y), 4), "|"),
      paste("| Max |", round(max(x), 4), "|", round(max(y), 4), "|")
    )
  } else {
    stats <- c(
      paste("| Sample Size |", length(x), "|"),
      paste("| Mean |", round(mean(x), 4), "|"),
      paste("| Standard Deviation |", round(sd(x), 4), "|"),
      paste("| Median |", round(median(x), 4), "|"),
      paste("| Min |", round(min(x), 4), "|"),
      paste("| Max |", round(max(x), 4), "|")
    )
  }
  
  return(c(content, stats))
}

generate_data_overview_html <- function(x, y) {
  content <- c(
    "        <table class='result-table'>",
    "            <tr><th>Statistic</th><th>Group X</th>"
  )
  
  if (!is.null(y)) {
    content <- c(content, "<th>Group Y</th>")
  }
  content <- c(content, "</tr>")
  
  if (!is.null(y)) {
    stats_rows <- c(
      paste0("            <tr><td>Sample Size</td><td>", length(x), "</td><td>", length(y), "</td></tr>"),
      paste0("            <tr><td>Mean</td><td>", round(mean(x), 4), "</td><td>", round(mean(y), 4), "</td></tr>"),
      paste0("            <tr><td>Standard Deviation</td><td>", round(sd(x), 4), "</td><td>", round(sd(y), 4), "</td></tr>"),
      paste0("            <tr><td>Median</td><td>", round(median(x), 4), "</td><td>", round(median(y), 4), "</td></tr>"),
      paste0("            <tr><td>Min</td><td>", round(min(x), 4), "</td><td>", round(min(y), 4), "</td></tr>"),
      paste0("            <tr><td>Max</td><td>", round(max(x), 4), "</td><td>", round(max(y), 4), "</td></tr>")
    )
  } else {
    stats_rows <- c(
      paste0("            <tr><td>Sample Size</td><td>", length(x), "</td></tr>"),
      paste0("            <tr><td>Mean</td><td>", round(mean(x), 4), "</td></tr>"),
      paste0("            <tr><td>Standard Deviation</td><td>", round(sd(x), 4), "</td></tr>"),
      paste0("            <tr><td>Median</td><td>", round(median(x), 4), "</td></tr>"),
      paste0("            <tr><td>Min</td><td>", round(min(x), 4), "</td></tr>"),
      paste0("            <tr><td>Max</td><td>", round(max(x), 4), "</td></tr>")
    )
  }
  
  content <- c(content, stats_rows, "        </table>")
  return(content)
}

generate_normality_assessment_md <- function(oneR_result) {
  content <- c(
    "The Shapiro-Wilk test was used to assess normality. This test evaluates whether the data follows a normal distribution.",
    "",
    "| Group | W Statistic | P-value | Normal? | Interpretation |",
    "|-------|-------------|---------|---------|----------------|",
    paste("| Group X |", round(oneR_result$normality_x$statistic, 4), "|", 
          round(oneR_result$normality_x$p.value, 4), "|", 
          ifelse(oneR_result$normality_x$p.value > oneR_result$parameters$alpha, "Yes", "No"), "|",
          ifelse(oneR_result$normality_x$p.value > oneR_result$parameters$alpha, "Data appears normally distributed", "Data deviates from normal distribution"), "|")
  )
  
  if (!is.null(oneR_result$normality_y)) {
    content <- c(content,
      paste("| Group Y |", round(oneR_result$normality_y$statistic, 4), "|", 
            round(oneR_result$normality_y$p.value, 4), "|", 
            ifelse(oneR_result$normality_y$p.value > oneR_result$parameters$alpha, "Yes", "No"), "|",
            ifelse(oneR_result$normality_y$p.value > oneR_result$parameters$alpha, "Data appears normally distributed", "Data deviates from normal distribution"), "|")
    )
  }
  
  return(content)
}

generate_normality_assessment_html <- function(oneR_result) {
  content <- c(
    "        <p>The Shapiro-Wilk test was used to assess normality. This test evaluates whether the data follows a normal distribution.</p>",
    "        <table class='result-table'>",
    "            <tr><th>Group</th><th>W Statistic</th><th>P-value</th><th>Normal?</th><th>Interpretation</th></tr>",
    paste0("            <tr><td>Group X</td><td>", round(oneR_result$normality_x$statistic, 4), 
           "</td><td>", round(oneR_result$normality_x$p.value, 4), 
           "</td><td><span class='", ifelse(oneR_result$normality_x$p.value > oneR_result$parameters$alpha, "normal'>Yes", "non-normal'>No"), 
           "</span></td><td>", ifelse(oneR_result$normality_x$p.value > oneR_result$parameters$alpha, "Data appears normally distributed", "Data deviates from normal distribution"), "</td></tr>")
  )
  
  if (!is.null(oneR_result$normality_y)) {
    content <- c(content,
      paste0("            <tr><td>Group Y</td><td>", round(oneR_result$normality_y$statistic, 4), 
             "</td><td>", round(oneR_result$normality_y$p.value, 4), 
             "</td><td><span class='", ifelse(oneR_result$normality_y$p.value > oneR_result$parameters$alpha, "normal'>Yes", "non-normal'>No"), 
             "</span></td><td>", ifelse(oneR_result$normality_y$p.value > oneR_result$parameters$alpha, "Data appears normally distributed", "Data deviates from normal distribution"), "</td></tr>")
    )
  }
  
  content <- c(content, "        </table>")
  return(content)
}

generate_test_results_md <- function(oneR_result) {
  test_result <- oneR_result$test_result
  
  content <- c(
    paste("**Test Selected:** ", oneR_result$test_used),
    "",
    "| Statistic | Value | Interpretation |",
    "|-----------|-------|----------------|",
    paste("| Test Statistic |", round(test_result$statistic, 4), "| The calculated test statistic |"),
    paste("| P-value |", round(test_result$p.value, 4), "|", 
          ifelse(test_result$p.value < oneR_result$parameters$alpha, "Statistically significant", "Not statistically significant"), "|"),
    paste("| Significance Level |", oneR_result$parameters$alpha, "| Threshold for statistical significance |")
  )
  
  if ("conf.int" %in% names(test_result)) {
    ci_level <- attr(test_result$conf.int, "conf.level") * 100
    content <- c(content,
      paste("|", ci_level, "% Confidence Interval | [", 
            round(test_result$conf.int[1], 4), ", ", 
            round(test_result$conf.int[2], 4), "] | Range of plausible values |")
    )
  }
  
  return(content)
}

generate_test_results_html <- function(oneR_result) {
  test_result <- oneR_result$test_result
  
  content <- c(
    paste0("        <p><strong>Test Selected:</strong> ", oneR_result$test_used, "</p>"),
    "        <table class='result-table'>",
    "            <tr><th>Statistic</th><th>Value</th><th>Interpretation</th></tr>",
    paste0("            <tr><td>Test Statistic</td><td>", round(test_result$statistic, 4), "</td><td>The calculated test statistic</td></tr>"),
    paste0("            <tr><td>P-value</td><td>", round(test_result$p.value, 4), "</td><td><span class='", 
           ifelse(test_result$p.value < oneR_result$parameters$alpha, "significant'>Statistically significant", "not-significant'>Not statistically significant"), 
           "</span></td></tr>"),
    paste0("            <tr><td>Significance Level</td><td>", oneR_result$parameters$alpha, "</td><td>Threshold for statistical significance</td></tr>")
  )
  
  if ("conf.int" %in% names(test_result)) {
    ci_level <- attr(test_result$conf.int, "conf.level") * 100
    content <- c(content,
      paste0("            <tr><td>", ci_level, "% Confidence Interval</td><td>[", 
             round(test_result$conf.int[1], 4), ", ", 
             round(test_result$conf.int[2], 4), "]</td><td>Range of plausible values</td></tr>")
    )
  }
  
  content <- c(content, "        </table>")
  return(content)
}

generate_interpretation_md <- function(oneR_result) {
  c(
    oneR_result$recommendation,
    "",
    "### Statistical Interpretation",
    "",
    ifelse(oneR_result$test_result$p.value < oneR_result$parameters$alpha,
           paste("With a p-value of", round(oneR_result$test_result$p.value, 4), 
                 "which is less than the significance level of", oneR_result$parameters$alpha,
                 ", we reject the null hypothesis. This suggests there is sufficient evidence for a statistically significant difference."),
           paste("With a p-value of", round(oneR_result$test_result$p.value, 4), 
                 "which is greater than or equal to the significance level of", oneR_result$parameters$alpha,
                 ", we fail to reject the null hypothesis. This suggests there is insufficient evidence for a statistically significant difference.")),
    "",
    "### Practical Considerations",
    "",
    "- Statistical significance does not necessarily imply practical significance",
    "- Consider the effect size and confidence intervals when interpreting results",
    "- Ensure that the assumptions of the chosen test are met",
    "- Consider the context and domain knowledge when drawing conclusions"
  )
}

generate_interpretation_html <- function(oneR_result) {
  c(
    paste0("            <p>", oneR_result$recommendation, "</p>"),
    "            <h3>Statistical Interpretation</h3>",
    paste0("            <p>", 
           ifelse(oneR_result$test_result$p.value < oneR_result$parameters$alpha,
                  paste("With a p-value of", round(oneR_result$test_result$p.value, 4), 
                        "which is less than the significance level of", oneR_result$parameters$alpha,
                        ", we reject the null hypothesis. This suggests there is sufficient evidence for a statistically significant difference."),
                  paste("With a p-value of", round(oneR_result$test_result$p.value, 4), 
                        "which is greater than or equal to the significance level of", oneR_result$parameters$alpha,
                        ", we fail to reject the null hypothesis. This suggests there is insufficient evidence for a statistically significant difference.")),
           "</p>"),
    "            <h3>Practical Considerations</h3>",
    "            <ul>",
    "                <li>Statistical significance does not necessarily imply practical significance</li>",
    "                <li>Consider the effect size and confidence intervals when interpreting results</li>",
    "                <li>Ensure that the assumptions of the chosen test are met</li>",
    "                <li>Consider the context and domain knowledge when drawing conclusions</li>",
    "            </ul>"
  )
}

generate_technical_details_md <- function(oneR_result) {
  c(
    paste("- **R Version:** ", R.version.string),
    paste("- **oneR Package Version:** 1.0.0"),
    paste("- **Analysis Date:** ", Sys.Date()),
    paste("- **Test Selection Algorithm:** Shapiro-Wilk normality test followed by appropriate parametric/non-parametric test"),
    "",
    "### Test Selection Logic",
    "",
    "1. **Normality Assessment:** Shapiro-Wilk test performed on all groups",
    "2. **Decision Rule:** If all groups pass normality (p > α), use parametric tests; otherwise use non-parametric tests",
    "3. **Parametric Tests:** t-tests (one-sample, two-sample, paired)",
    "4. **Non-parametric Tests:** Wilcoxon tests (signed-rank, rank-sum)",
    "",
    "### Assumptions and Limitations",
    "",
    "- Shapiro-Wilk test is most reliable for sample sizes between 3 and 5000",
    "- Independence of observations is assumed",
    "- For two-sample tests, equal variances are assumed for t-tests",
    "- Non-parametric tests have fewer assumptions but may have lower power"
  )
}

generate_technical_details_html <- function(oneR_result) {
  c(
    "        <ul>",
    paste0("            <li><strong>R Version:</strong> ", R.version.string, "</li>"),
    "            <li><strong>oneR Package Version:</strong> 1.0.0</li>",
    paste0("            <li><strong>Analysis Date:</strong> ", Sys.Date(), "</li>"),
    "            <li><strong>Test Selection Algorithm:</strong> Shapiro-Wilk normality test followed by appropriate parametric/non-parametric test</li>",
    "        </ul>",
    "        <h3>Test Selection Logic</h3>",
    "        <ol>",
    "            <li><strong>Normality Assessment:</strong> Shapiro-Wilk test performed on all groups</li>",
    "            <li><strong>Decision Rule:</strong> If all groups pass normality (p > α), use parametric tests; otherwise use non-parametric tests</li>",
    "            <li><strong>Parametric Tests:</strong> t-tests (one-sample, two-sample, paired)</li>",
    "            <li><strong>Non-parametric Tests:</strong> Wilcoxon tests (signed-rank, rank-sum)</li>",
    "        </ol>",
    "        <h3>Assumptions and Limitations</h3>",
    "        <ul>",
    "            <li>Shapiro-Wilk test is most reliable for sample sizes between 3 and 5000</li>",
    "            <li>Independence of observations is assumed</li>",
    "            <li>For two-sample tests, equal variances are assumed for t-tests</li>",
    "            <li>Non-parametric tests have fewer assumptions but may have lower power</li>",
    "        </ul>"
  )
}

generate_raw_data_md <- function(x, y) {
  content <- c(
    "### Group X Data",
    "",
    "```",
    paste(round(x, 4), collapse = ", "),
    "```"
  )
  
  if (!is.null(y)) {
    content <- c(content,
      "",
      "### Group Y Data",
      "",
      "```",
      paste(round(y, 4), collapse = ", "),
      "```"
    )
  }
  
  return(content)
}

generate_raw_data_html <- function(x, y) {
  content <- c(
    "        <h3>Group X Data</h3>",
    "        <div class='code-block'>",
    paste("           ", paste(round(x, 4), collapse = ", ")),
    "        </div>"
  )
  
  if (!is.null(y)) {
    content <- c(content,
      "        <h3>Group Y Data</h3>",
      "        <div class='code-block'>",
      paste("           ", paste(round(y, 4), collapse = ", ")),
      "        </div>"
    )
  }
  
  return(content)
}

