#' Automated Statistical Testing with Normality Assessment
#'
#' This function performs automated statistical testing by first assessing normality
#' using the Shapiro-Wilk test, then selecting appropriate parametric or non-parametric
#' tests based on the normality results.
#'
#' @param x A numeric vector for one-sample tests, or the first group for two-sample tests
#' @param y An optional numeric vector for two-sample tests (default: NULL)
#' @param mu The hypothesized mean for one-sample tests (default: 0)
#' @param alternative The alternative hypothesis: "two.sided", "less", or "greater" (default: "two.sided")
#' @param alpha The significance level for normality testing (default: 0.05)
#' @param conf.level The confidence level for the test (default: 0.95)
#' @param paired Logical indicating whether to perform a paired test (default: FALSE)
#'
#' @return A list containing:
#' \itemize{
#'   \item normality_x: Results of Shapiro-Wilk test for x
#'   \item normality_y: Results of Shapiro-Wilk test for y (if provided)
#'   \item is_normal: Logical indicating if data passes normality test(s)
#'   \item test_used: Character string indicating which test was performed
#'   \item test_result: Results of the statistical test
#'   \item recommendation: Text recommendation based on results
#' }
#'
#' @examples
#' # One-sample test
#' set.seed(123)
#' normal_data <- rnorm(30, mean = 5, sd = 2)
#' result1 <- oneR_test(normal_data, mu = 5)
#' 
#' # Two-sample test
#' group1 <- rnorm(25, mean = 10, sd = 3)
#' group2 <- rnorm(25, mean = 12, sd = 3)
#' result2 <- oneR_test(group1, group2)
#'
#' @export
oneR_test <- function(x, y = NULL, mu = 0, alternative = "two.sided", 
                      alpha = 0.05, conf.level = 0.95, paired = FALSE) {
  
  # Input validation
  if (!is.numeric(x)) {
    stop("x must be a numeric vector")
  }
  
  if (!is.null(y) && !is.numeric(y)) {
    stop("y must be a numeric vector or NULL")
  }
  
  if (length(x) < 3) {
    stop("x must have at least 3 observations for normality testing")
  }
  
  if (!is.null(y) && length(y) < 3) {
    stop("y must have at least 3 observations for normality testing")
  }
  
  # Remove missing values
  x <- x[!is.na(x)]
  if (!is.null(y)) {
    y <- y[!is.na(y)]
  }
  
  # Perform normality tests
  normality_x <- shapiro.test(x)
  normality_y <- NULL
  
  if (!is.null(y)) {
    normality_y <- shapiro.test(y)
  }
  
  # Determine if data is normal
  is_normal_x <- normality_x$p.value > alpha
  is_normal_y <- if (!is.null(y)) normality_y$p.value > alpha else TRUE
  is_normal <- is_normal_x && is_normal_y
  
  # Perform appropriate statistical test
  if (is.null(y)) {
    # One-sample test
    if (is_normal) {
      test_result <- t.test(x, mu = mu, alternative = alternative, conf.level = conf.level)
      test_used <- "One-sample t-test"
    } else {
      test_result <- wilcox.test(x, mu = mu, alternative = alternative, conf.level = conf.level)
      test_used <- "One-sample Wilcoxon signed-rank test"
    }
  } else {
    # Two-sample test
    if (is_normal) {
      test_result <- t.test(x, y, alternative = alternative, conf.level = conf.level, paired = paired)
      test_used <- if (paired) "Paired t-test" else "Two-sample t-test"
    } else {
      test_result <- wilcox.test(x, y, alternative = alternative, conf.level = conf.level, paired = paired)
      test_used <- if (paired) "Paired Wilcoxon signed-rank test" else "Two-sample Wilcoxon rank-sum test"
    }
  }
  
  # Generate recommendation
  recommendation <- generate_recommendation(test_result, test_used, is_normal, alpha)
  
  # Return results
  result <- list(
    normality_x = normality_x,
    normality_y = normality_y,
    is_normal = is_normal,
    test_used = test_used,
    test_result = test_result,
    recommendation = recommendation,
    data_x = x,
    data_y = y,
    parameters = list(
      mu = mu,
      alternative = alternative,
      alpha = alpha,
      conf.level = conf.level,
      paired = paired
    )
  )
  
  class(result) <- "oneR"
  return(result)
}

#' Generate recommendation text based on test results
#'
#' @param test_result Results from statistical test
#' @param test_used Name of the test performed
#' @param is_normal Whether data passed normality tests
#' @param alpha Significance level
#'
#' @return Character string with recommendation
#' @keywords internal
generate_recommendation <- function(test_result, test_used, is_normal, alpha) {
  p_value <- test_result$p.value
  
  normality_text <- if (is_normal) {
    "Data passed normality tests (Shapiro-Wilk), so parametric test was used."
  } else {
    "Data failed normality tests (Shapiro-Wilk), so non-parametric test was used."
  }
  
  significance_text <- if (p_value < alpha) {
    paste0("The test result is statistically significant (p = ", 
           round(p_value, 4), " < ", alpha, "). ")
  } else {
    paste0("The test result is not statistically significant (p = ", 
           round(p_value, 4), " >= ", alpha, "). ")
  }
  
  if (grepl("t-test", test_used)) {
    if (p_value < alpha) {
      conclusion <- "There is sufficient evidence to reject the null hypothesis."
    } else {
      conclusion <- "There is insufficient evidence to reject the null hypothesis."
    }
  } else {
    if (p_value < alpha) {
      conclusion <- "There is sufficient evidence to reject the null hypothesis."
    } else {
      conclusion <- "There is insufficient evidence to reject the null hypothesis."
    }
  }
  
  return(paste(normality_text, significance_text, conclusion))
}

